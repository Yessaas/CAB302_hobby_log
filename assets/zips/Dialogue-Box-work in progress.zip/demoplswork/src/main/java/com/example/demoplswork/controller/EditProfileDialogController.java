package com.example.demoplswork.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class EditProfileDialogController {

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    private Stage dialogStage;

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    @FXML
    private void handleSave(ActionEvent event) {
        // Get the values from the text fields
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String email = emailField.getText();
        String password = passwordField.getText();

        // Logic to save the edited profile data
        System.out.println("Profile Updated: First Name: " + firstName + ", Last Name: " + lastName + ", Email: " + email);

        // Close the dialog
        dialogStage.close();
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        // Close the dialog without saving
        dialogStage.close();
    }
}
